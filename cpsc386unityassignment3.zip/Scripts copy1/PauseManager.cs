using UnityEngine;

public class PauseManager : MonoBehaviour
{
    public void PauseGame()
    {
        // Pauses the game
        Time.timeScale = 0f;

        // Shows the save button if needed
        GameObject saveButton = GameObject.Find("SaveButton");
        if (saveButton != null)
        {
            saveButton.SetActive(true);
        }
        else
        {
            Debug.LogWarning("Save button not found!");
        }
    }
}
