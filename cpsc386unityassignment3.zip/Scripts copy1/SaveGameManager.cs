using UnityEngine;
using UnityEngine.SceneManagement;

public class SaveGameManager : MonoBehaviour
{
    public void SaveGame()
    {
        // Saves Ball position
        SaveObjectPosition("Ball", "Ball");

        // Saves Ground position
        SaveObjectPosition("Ground", "Ground");

        // Saves each Coin position
        GameObject[] coins = GameObject.FindGameObjectsWithTag("Coin");
        for (int i = 0; i < coins.Length; i++)
        {
            SaveObjectPosition("Coin" + i, coins[i].name);
        }

        Debug.Log("Game saved!");

        // Returns to menu scene
        SceneManager.LoadScene("MenuScene");
    }

    public void LoadGame()
    {
        // Loads Ball position
        LoadObjectPosition("Ball", "Ball");

        // Loads Ground position
        LoadObjectPosition("Ground", "Ground");

        // Loads each Coin position
        GameObject[] coins = GameObject.FindGameObjectsWithTag("Coin");
        for (int i = 0; i < coins.Length; i++)
        {
            LoadObjectPosition("Coin" + i, coins[i].name);
        }

        Debug.Log("Game loaded!");

        // Return to game scene
        SceneManager.LoadScene("GameScene");
    }

    private void SaveObjectPosition(string keyPrefix, string gameObjectName)
    {
        GameObject obj = GameObject.FindWithTag(gameObjectName);
        if (obj != null)
        {
            Vector3 position = obj.transform.position;
            PlayerPrefs.SetFloat(keyPrefix + "X", position.x);
            PlayerPrefs.SetFloat(keyPrefix + "Y", position.y);
            PlayerPrefs.SetFloat(keyPrefix + "Z", position.z);
        }
    }

    private void LoadObjectPosition(string keyPrefix, string gameObjectName)
    {
        Vector3 position = new Vector3(
            PlayerPrefs.GetFloat(keyPrefix + "X"),
            PlayerPrefs.GetFloat(keyPrefix + "Y"),
            PlayerPrefs.GetFloat(keyPrefix + "Z")
        );
        GameObject obj = GameObject.FindWithTag(gameObjectName);
        if (obj != null)
        {
            obj.transform.position = position;
        }
    }
}
